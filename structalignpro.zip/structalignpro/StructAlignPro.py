# StructAlignPro.py
"""
# StructAlignPro
This script is designed to optimize the usage of DaliLite.v5 for protein structure comparison.
It provides a simplified interface and enhanced functionalities, making it easier for users to perform structural alignments. This script has been developed with Python version 3.12.4.
## License
This project is licensed under the MIT License. See the LICENSE file for more details.
## Author
wqiudao@gmail.com
## Date
2024-09
## Usage
Usage: StructAlignPro [-h] {makedalidb,pdb2dalidb,comparepdb} ...
Structure Alignment Program
positional arguments:
  {makedalidb,pdb2dalidb,comparepdb}
    pdb2dalidb          Compare a PDB file with DALI database.
    comparepdb          Compare two PDB files.
	makedalidb          Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural searches.
options:
  -h, --help
"""
import argparse,os,random,sys,shutil,subprocess,re,datetime
from collections import defaultdict
def remove_extension(pdb_file):
	file_name, _ = os.path.splitext(pdb_file)
	return file_name
def replace_mol1_in_file(mol_txt, new_name1, new_name2=0):
	if not os.path.isfile(mol_txt):
		print(f"\033[91mERROR: The absence of the result file '{mol_txt}' indicates that DaliLite did not run correctly. This may be due to improper configuration of the dependency environment.\033[0m")
		return
	with open(mol_txt, 'r') as f:
		content = f.read()
	if new_name2:	  
		updated_content = content.replace("mol1", remove_extension(new_name1)).replace("mol2", remove_extension(new_name2))
	else:
		updated_content = content.replace("mol1", remove_extension(new_name1))

	with open(mol_txt, 'w') as f:
		f.write(updated_content)
def makedalidb(src_directory,dest_directory,random_number=1000,bin_dali='bin_DaliLite.v5.1'):
	new_names_dali=set()
	new_names_dali2symbol={}
	log_file=f'{dest_directory}/dali.log'
	hash_file=f'{dest_directory}/dali.hash'
	list_file=f'{dest_directory}/dali.list'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)	
	# pdb_files_with_random = {}
	old2new_names = {}
	new2ole_names = {}
	for root, dirs, files in os.walk(src_directory):
		for file in files:
			if file.endswith('.pdb'):
				random_number += 1
				new_filename = f"{random_number}.pdb"
				src_file_path = os.path.join(root, file)
				dest_file_path = os.path.join(dest_directory, new_filename)
				
				shutil.copy(src_file_path, dest_file_path)
				new_names_dali.add(dest_file_path)
				new_names_dali2symbol[dest_file_path]=str(random_number)
				old2new_names[file] = new_filename
				new2ole_names[str(random_number)] = file
				# print(f'{file} {new_filename}')
	log_file=open(log_file, 'w')
	hash_file=open(hash_file, 'w')
	list_file=open(list_file, 'w')
	for old_name, new_name in old2new_names.items():
		hash_file.write(f"Old Name: {old_name}, New Name: {new_name}\n")
		list_file.write(f"{new_name.split('.')[0]}A\n")
	hash_file.close()
	list_file.close()
	command = ['chmod', '-R', '+x', os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}']
	result = subprocess.run(command, check=True, capture_output=True, text=True)
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/import.pl'
	for filename in new_names_dali:
		# print(f'{new2ole_names[new_names_dali2symbol[filename]]} {filename}')
		# print(new_names_dali2symbol[filename])  running  run_Log
		result = subprocess.Popen(
			['perl', perl_script, '--pdbfile', filename, '--pdbid', new_names_dali2symbol[filename], '--dat', dest_directory, '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
		)
		stdout, stderr = result.communicate()		
		log_file.write(f">>>{new2ole_names[new_names_dali2symbol[filename]]} {filename}<<<\n\n") 
		log_file.write(f"{stdout.decode('utf-8')}")  
		log_file.write(f"{stderr.decode('utf-8')}\n\n") 		
	ref_dali_db=f"{os.getcwd()}/{dest_directory}"
	run_script = 'structalignpro pdb2dalidb'
	print(f"\n{ref_dali_db}\n")
	log_file.close()
	log_file=open(dest_directory+".dali_ref.log", 'w')
	log_file.write(f"{run_script} {ref_dali_db} entry.pdb\n")	
	log_file.close()


def recover_name(pdb2id, query,out_file,pdb,ref_dali_db):
	id2pdb=defaultdict(str) # hash filename  mol1A.txt
	pdb2id_file=open(pdb2id)
	reads=pdb2id_file.readline()
	while reads:
		readss=re.split(r',',reads)
		if len(readss)>1:
			pdb_symbol=re.search(r'(\S+).pdb',readss[0])
			pdb_id=re.search(r'(\d+).pdb',readss[1])
			if pdb_symbol and pdb_id:
				id2pdb[pdb_id.group(1)+'A']=pdb_symbol.group(1).split('___')[0]
				id2pdb[pdb_id.group(1)+'-A']=pdb_symbol.group(1).split('___')[0]
		reads=pdb2id_file.readline()
	pdb2id_file.close()
	query_symbol=open(out_file,'w')
	query_symbol.write(f">>>{pdb} {ref_dali_db}<<<\n\n") 	
	query_file=open(query)
	os.remove('pdbfile1')
	os.remove('ref_dali_db_short')
	reads=query_file.readline()
	while reads:
		for old_name in id2pdb:
			new_name=id2pdb[old_name]
			reads = re.sub(r'\b' + re.escape(old_name) + r'\b', new_name, reads)
		query_symbol.write(reads)
		reads=query_file.readline()
	query_file.close()
	query_symbol.close()

def pdb2dalidb(pdb,ref_dali_db,getcwd_pdb,bin_dali='bin_DaliLite.v5.1'):
	current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
	print(f"\033[92m{current_time}\033[0m")
	ref_dali_db_log=ref_dali_db
	if ref_dali_db== 'StructCores':
		ref_dali_db = os.path.join(os.path.dirname(os.path.abspath(__file__)), ref_dali_db)

	filename=f'{getcwd_pdb}/{pdb}'
	ref_dali_db = ref_dali_db.rstrip('/')	
	if not os.path.isabs(ref_dali_db):
		ref_dali_db = os.path.join(os.getcwd(), ref_dali_db)
	# max_length = 70
	# if len(filename) > max_length or len(ref_dali_db) > max_length:
		# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\nThe full path of the directory where the file is located is too lengthy.\033[0m")	
		# print(f"\033[91m{filename}\033[0m")	
		# print(f"\033[91m{ref_dali_db}\033[0m")	
	if not os.path.isdir(ref_dali_db):
		raise FileNotFoundError(f"{ref_dali_db} is not a directory.")
	required_files = ['dali.hash', 'dali.list']
	for file in required_files:
		if not os.path.isfile(os.path.join(ref_dali_db, file)):
			raise FileNotFoundError(f"{file} not found in {ref_dali_db}.")

	dali_ref_list=f'{ref_dali_db}/dali.list'
	dali2symbol=f'{ref_dali_db}/dali.hash'
	# dest_directory=pdb.split(".")[0]+'_dali_rs'
	dest_directory=f'StructAlignPro_{pdb.split(".")[0]}_{current_time}_running'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	out_file=f'{getcwd_pdb}/StructAlignPro_{pdb.split(".")[0]}_{current_time}_result.txt'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	# log_file=open(log_file, 'w')
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	shutil.copy(filename, dest_directory)
	print(filename)	
	# print(dali_ref_list)
	# print(dali2symbol)
	# print(f"{os.getcwd()}")
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/dali.pl'
	os.chdir(dest_directory)
	
	os.symlink(pdb, 'pdbfile1')	
	os.symlink(ref_dali_db, 'ref_dali_db_short')	
	
	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--db', dali_ref_list, '--dat1','.', '--dat2', 'ref_dali_db_short', '--title', pdb, '--outfmt','summary,alignments,equivalences,transrot', '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
	)
	stdout, stderr = result.communicate()
	
	log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{current_time}.run.log'
	log_file=open(log_file, 'w')

	log_file.write(f">>>{pdb} {ref_dali_db_log}<<<\n\n") 
	

	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n")
	
	replace_mol1_in_file("mol1A.txt", pdb)
	recover_name(dali2symbol, "mol1A.txt",out_file,pdb,ref_dali_db_log)
	log_file.close()
	print(out_file)



def pdb2pdb(pdb1,pdb2,getcwd_pdb,bin_dali='bin_DaliLite.v5.1'):
	current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
	print(f"\033[92m{current_time}\033[0m")	
	dest_directory=f'StructAlignPro_{pdb1.split(".")[0]}_vs_{pdb2.split(".")[0]}_{current_time}_running'
	out_file=f'{getcwd_pdb}/StructAlignPro_{pdb1.split(".")[0]}_vs_{pdb2.split(".")[0]}_{current_time}_result.txt'	
	# print(pdb1)	
	# print(pdb2)		
	filename1=f'{getcwd_pdb}/{pdb1}'
	filename2=f'{getcwd_pdb}/{pdb2}'
	# log_file=f'{pdb.split(".")[0]}_pdb2dalidb_{datetime.datetime.now()}.run.log'
	if os.path.exists(dest_directory):
		shutil.rmtree(dest_directory)
	os.makedirs(dest_directory)		
	shutil.copy(filename1, dest_directory)
	shutil.copy(filename2, dest_directory)
	# print(filename1)
	# print(filename2)
	# print(f"{os.getcwd()}")
	perl_script = os.path.dirname(os.path.abspath(__file__))+f'/{bin_dali}/dali.pl'
	os.chdir(dest_directory)
	os.symlink(pdb1, 'pdbfile1')		
	os.symlink(pdb2, 'pdbfile2')		
	result = subprocess.Popen(
		['perl', perl_script, '--pdbfile1', 'pdbfile1', '--pdbfile2', 'pdbfile2', '--dat1','.', '--dat2','.', '--title', f'{pdb1} {pdb2}', '--outfmt','summary,alignments,equivalences,transrot', '--clean'],stdout=subprocess.PIPE,stderr=subprocess.PIPE
		
	)
	log_file=f'{pdb1.split(".")[0]}_pdb2dalidb_{current_time}.run.log'
	log_file=open(log_file, 'w')
	stdout, stderr = result.communicate()
	log_file.write(f">>>{pdb1} {pdb2}<<<\n\n") 
	log_file.write(f"{stdout.decode('utf-8')}")  
	log_file.write(f"{stderr.decode('utf-8')}\n\n") 	
	# recover_name(dali2symbol, "mol1A.txt",out_file,pdb,ref_dali_db)
	log_file.close()
	# print(dest_directory)
	replace_mol1_in_file("mol1A.txt", pdb1, pdb2)
	os.remove('pdbfile1')	
	os.remove('pdbfile2')	
	print(out_file)
	os.chdir('..')
	shutil.copy(f'{dest_directory}/mol1A.txt',out_file )

def main():
	parser = argparse.ArgumentParser(prog='structalignpro', description='Structure Alignment Program')
	subparsers = parser.add_subparsers(dest='command')
	
	
	# pdb2dalidb command
	pdb2dalidb_parser = subparsers.add_parser('pdb2dalidb', help='Compare a PDB file with DALI database.')
	pdb2dalidb_parser.add_argument('entry_pdb', type=str, help='PDB file to be compared.')
	pdb2dalidb_parser.add_argument('--dali_database', type=str,default='StructCores',help='Provide a custom database path if needed. By default, uses its built-in core database with experimentally determined CRISPR-Cas structures.')

	# comparepdb command
	comparepdb_parser = subparsers.add_parser('comparepdb', help='Compare two PDB files.')
	comparepdb_parser.add_argument('pdb_file_1', type=str, help='Path to the first PDB file for comparison.')
	comparepdb_parser.add_argument('pdb_file_2', type=str, help='Path to the second PDB file for comparison.')
	comparepdb_parser.description = (
		'This command compares two PDB files, providing structural alignment '
		'information between them.'
	)


	# makedalidb command
	makedalidb_parser = subparsers.add_parser('makedalidb', help='Create DALI database: Converts a set of PDB files to DALI format numbers for subsequent structural searches.')
	makedalidb_parser.add_argument('directory', type=str, help='Directory containing PDB files.')
	makedalidb_parser.add_argument('--dali_database', type=str, help='Directory for storing the output database files (default: <pdb_folder>_dali_db)')




	args = parser.parse_args()
	if args.command == 'makedalidb':
		if os.path.isdir(args.directory):	
			print(f'Generating DALI database from {args.directory}...')
			dalidb_dir=args.directory
			dalidb_dir = dalidb_dir.rstrip('/')
			dest_directory=f'{dalidb_dir}_dali'
			if args.dali_database:
				dest_directory=args.dali_database
			if dalidb_dir==dest_directory:
				dest_directory=f'{dalidb_dir}_dali'	
			makedalidb(dalidb_dir,dest_directory)
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.directory} does not exist.\033[0m")
			
		# makedalidb(src_directory)  dest_directory=src_directory+'_dali' mol1A.txt.symbol.txt
	elif args.command == 'pdb2dalidb':	
		if os.path.isfile(args.entry_pdb):
			print(f'Comparing {args.entry_pdb} with database {args.dali_database}...')	
			# max_length = 70
			# if len(args.entry_pdb) > max_length or len(args.dali_database) > max_length:
				# print(f"\033[91mERROR: Input parameters must not exceed 70 characters.\033[0m")
				# return 0
			pdb2dalidb(args.entry_pdb,args.dali_database,f"{os.getcwd()}")
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.entry_pdb} does not exist.\033[0m")
		
	elif args.command == 'comparepdb':
		if os.path.isfile(args.pdb_file_1) and  os.path.isfile(args.pdb_file_2):
			print(f'Comparing {args.pdb_file_1} with another PDB file  {args.pdb_file_2}...')
			pdb2pdb(args.pdb_file_1,args.pdb_file_2,f"{os.getcwd()}",bin_dali='bin_DaliLite.v5.1')
			print(f"\033[92mDone\033[0m")
		else:
			print(f"\033[91mThe file {args.pdb_file_1} or {args.pdb_file_2} does not exist.\033[0m")
	else:
		parser.print_help()

if __name__ == '__main__':
	main()

